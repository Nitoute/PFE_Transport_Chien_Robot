The sources in form of an eclipse 3.6 project. 

Usage: 
 1) Dowload the desired version. 
 2) Deflate it (use winrar, winzip, ...).
 3) Start eclipse. 
 4) Choose: file->import->existing project into workspace.
 5) Point to the deflated directory "jchar2d"
 6) Start developing. I recommend to use the shipped 
    ANT build.xml: Right click the file and choose 
    "ANT build...". 
 
 7) Contribute, report bugs, read the LGPL! 
    I did not change anything between 2002 and 2005, as 
    nothing was reported. Just some friends who used it 
    personally informed me about bugs. Open Source needs 
    feedback. 
